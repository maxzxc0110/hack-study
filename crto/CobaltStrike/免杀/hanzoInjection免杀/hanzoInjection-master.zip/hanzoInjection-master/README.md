### HanzoInjection 
the HanzoIjection is a tool focused on injecting arbitrary codes in memory to bypass common antivirus solutions
```
the HanzoIjection is a tool focused on injecting arbitrary codes in memory to by
pass common antivirus solutions.

Developer: Mharcos Nesster (mh4x0f)
Email:mh4root@gmail.com
Greetx:  P0cL4bs Team { N4sss , MMXM , Chrislley, MovCode, joridos }
-------------------------------------------------------------------


Arguments Options:

        OPTION        TYPE       DESCRIPTION
       -e,--execute  [.raw]      Name of file.bin, payload metasploit type raw
       -p,--payload  [.raw]      Payload meterpreter type [RAW]  requered parameter -o [output]
       -o,--output   [file.cs]   Output generate project file.cs injection memory payload c#
       -h,--help     [Help]      show this help and exit

Example Usage:

        HanzoInjection.exe -e payload_meterpreter.bin
        HanzoInjection.exe -p meterpreter.bin -o injection_memory.cs
```

Video Demo: https://www.youtube.com/watch?v=1Bb7ZuM3sho&list=UUx8AOiQBPughNfA-PsASZ9w

